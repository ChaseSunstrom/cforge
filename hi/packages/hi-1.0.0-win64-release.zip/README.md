# hi Workspace

This package contains the following projects:

- **proj1**
- **proj2**

Each project is in its own subdirectory.
